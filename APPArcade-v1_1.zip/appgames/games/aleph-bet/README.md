# The Aleph-Bet Mystery: The Golem of the Lost Letters (v1)

A top-down 2D Zelda-inspired action-adventure in **one self-contained `index.html`** — no build step, no external assets. All art is drawn in code (canvas), all music and sound effects are generated in code (WebAudio). Works on desktop (keyboard) and phones/tablets (on-screen touch controls appear automatically).

**Design by Caiden · built for the Fullingim family APPGames collection.**

## Play it

Open `index.html` in any browser, or serve the folder from GitHub Pages and open `games/aleph-bet/`.

## Controls

| Action | Desktop | Touch |
|---|---|---|
| Move | WASD / arrow keys | D-pad |
| Sword / talk / open / confirm | Space, J, or Enter | A button |
| Emet's power (wake mechanisms) | Shift or K | B button |
| Pause menu (Letters, Quests, Save, Sound) | Esc or P | ☰ Menu |
| Mute | M | menu |

## What's in v1 (the 10–20 min demo)

- **House of Letters** — intro: the Book of Creation fractures; an Aleph shard awakens **Emet**, the clay golem companion who follows you (press **B** near golden א pedestals to wake ancient mechanisms).
- **Emberdust Plains** (2 screens) + **Kessef Village** with **3 side quests**: The Word for Bread (Tova), A Boy and his Dog (Dov + Kelev the dog follower), The Torn Blessing (Miriam, 3 scroll fragments). Each rewards a heart container.
- **The Forgotten Scriptorium** (dungeon): block-and-switch puzzle → study key; the **Reading Door** — a real letter-recognition puzzle (strike the true א among decoys; wrong stones bite back); a locked boss door that requires both.
- **Boss: The Ink Wraith** — 3-phase pattern fight (spread shots → faster → summons inkblots) with a health bar.
- **Shrine of the First Letter** — recover the Aleph (shape / name / sound / meaning taught), then complete the word **אמת (Emet — Truth)** on the golem's brow to finish the demo.
- Classic-Zelda difficulty: real hearts, real game over (return to last save), enemies respawn per room.
- **Saves**: auto-save at room transitions and story beats + manual save in the pause menu (localStorage, per device).
- Letter Collection screen showing all 22 letters (1/22 recovered in v1).

## Code structure (all inside index.html)

The script is organized into commented modules, in order:

| Module | What it does |
|---|---|
| `[CONST]` | tile size, room size, helpers |
| `[INPUT]` | keyboard + touch (one shared key map) |
| `[AUDIO]` | `Audio2` — generative music loop + all SFX |
| `[LETTERS]` | `LETTERS[]` — all 22 letters with name/glyph/sound/word/meaning/power |
| `[MAPS]` | `MAPS{}` — every room as ASCII tile strings + doors/edges/spawns |
| `[SPRITES]` | `drawTile`, `drawPlayer`, `drawEmet`, `drawEnemy`, `drawBoss`, … |
| `[ENTITY]` | `Player`, `Emet`, factories: `makeEnemy/makeNPC/makeChest/makeBlock/makeDog/makeBoss` |
| `[DIALOG]` | `Dialog` (typewriter + choices), `NPCS`, `Quests` |
| `[PUZZLES]` | `Puzzles` — Reading Door rows + block/switch checks |
| `[ROOMS]` | `loadRoom`, doors, gates, collision (`solidAt`, `moveWithCollision`) |
| `[SAVE]` | `autoSave` / `loadSave` (localStorage key `alephbet_v1`) |
| `[UI]` | HUD, pause `Menu`, Letters/Quests/Help pages |
| `[SCENES+LOOP]` | title / play / boss / gameover / ending + `tick()` |

## How to extend

**Add a room:** add an entry to `MAPS` (20×13 tile strings using the legend at the top of `[MAPS]`), then connect it with `doors:{'x,y':{to:'roomId',x,y}}` or `edges:{up/down/left/right:'roomId'}`.

**Add an enemy type:** in `makeEnemy`, add a `kind` with hp/speed and an AI branch; add a `drawEnemy` case.

**Add an NPC + quest:** add to `NPCS`, place with `{t:'npc',id,x,y}` in a room's `spawns`, add a def to `Quests.defs` (`need()` = completion check) and dialogue branches in `Quests.talk`.

**Add the next letter (e.g. Bet):** `LETTERS[1]` already has its data. Recover it somewhere (call `Game.found.push(1)`), then give Emet a new power in `Emet.action()` gated on `Game.found.includes(1)` — e.g. Bet reveals hidden rooms.

**Add a dungeon:** copy the five `d_*` rooms as a template — entry hall with locked door, two puzzle wings, boss room (`boss:true` + `makeBoss` variant), reward shrine.

## v1 known scope limits

Single letter recovered (Aleph); village house interiors are decorative; one boss; no shops/currency yet. All intentional — the systems above are built to grow.
