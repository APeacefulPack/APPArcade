# push-to-github.ps1 — puts the APP Arcade files into APeacefulPack/APPArcade
# HOW TO USE:
#   1. Download APPArcade-v1.zip from the chat and extract it (you get a folder called "appgames")
#   2. Open PowerShell IN that extracted "appgames" folder (right-click > Open in Terminal)
#   3. Run:  .\push-to-github.ps1   (if blocked: powershell -ExecutionPolicy Bypass -File .\push-to-github.ps1)
#   It will ask for your GitHub login in the browser the first time.

$repo = "https://github.com/APeacefulPack/APPArcade.git"

git init
git add index.html README.md games
git commit -m "APP Arcade v1: landing page + The Aleph-Bet Mystery (design by Caiden)"
git branch -M main
git remote add origin $repo
# The repo already has a README from creation; take ours over it:
git fetch origin
git pull origin main --allow-unrelated-histories --strategy-option=ours --no-edit
git push -u origin main

Write-Host ""
Write-Host "Done! Now enable GitHub Pages once:"
Write-Host "  Repo Settings > Pages > Deploy from a branch > main / (root) > Save"
Write-Host "  Game will be live at: https://apeacefulpack.github.io/APPArcade/"
