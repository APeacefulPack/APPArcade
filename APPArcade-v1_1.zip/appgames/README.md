# APP Arcade

Every game our team has made, in one place. Each game lives in its own folder under `games/` as a fully self-contained `index.html` (no build step, no dependencies), and the root `index.html` is the arcade landing page.

## Games

| Game | Path | Description |
|---|---|---|
| **The Aleph-Bet Mystery: The Golem of the Lost Letters** | `games/aleph-bet/` | Top-down Zelda-style adventure. Design by Caiden. See its README for controls and how to extend it. |

## Playing via GitHub Pages

Enable Pages once (repo **Settings → Pages → Deploy from a branch → `main` / root**) and the arcade is live at:

```
https://apeacefulpack.github.io/APPArcade/
```

Each game is playable at `https://apeacefulpack.github.io/APPArcade/games/<game>/`.

## Adding a new game

1. Create `games/<your-game>/index.html` (self-contained — inline CSS/JS, no external assets).
2. Add a card for it in the root `index.html` (copy an existing `<a class="card">` block).
3. Add a row to the table above.
